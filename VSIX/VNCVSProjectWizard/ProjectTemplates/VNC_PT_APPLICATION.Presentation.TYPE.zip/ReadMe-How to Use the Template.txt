﻿$safeprojectname$

Description

Usage
1. Replace APPLICATION with the name of the Application, e.g. CustomPoolAndSpa
2. Replace TYPE with the name of the type, e.g. Customer
3. Replace EVENT with the name of the Event, e.g. OpenCustomerDetailView

Start with Match Case search

Open each file and Rename File to Match Type
Best to do the Xaml renames with RightClick

Add References as Needed
VNC.Core
APPLICATION.DOMAIN
APPLICATION.DomainServices
APPLICATION.Core

Add Events as needed to APPLICATION.Core.Events

Open each file and Rename File to Match Type
Best to do the Xaml renames with RightClick