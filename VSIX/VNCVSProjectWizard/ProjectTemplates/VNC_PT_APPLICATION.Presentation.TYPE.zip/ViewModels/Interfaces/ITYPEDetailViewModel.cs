﻿using System.Threading.Tasks;

using VNC.Core.Mvvm;

namespace $safeprojectname$.ViewModels
{
    public interface I$customTYPE$DetailViewModel : IViewModel
    {
        Task LoadAsync(int id);
    }
}
