﻿using VNC.Core.Mvvm;

namespace $safeprojectname$.Views
{
    public interface I$customTYPE$ : IView
    {
    }
}
