﻿using System.Threading.Tasks;

using VNC.Core.Mvvm;

namespace $safeprojectname$.ViewModels
{
    public interface I$customTYPE$ViewModel : IViewModel
    {
        Task LoadAsync();
    }
}
