﻿namespace $safeprojectname$.Customers.Queries.GetCustomerList
{
    public class $customTYPE$Model
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
