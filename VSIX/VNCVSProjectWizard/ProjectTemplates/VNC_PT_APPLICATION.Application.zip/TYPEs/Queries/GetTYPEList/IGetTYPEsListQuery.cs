﻿using System.Collections.Generic;

namespace $safeprojectname$.$customTYPE$.Queries.Get$customTYPE$List
{
    public interface IGet$customTYPE$sListQuery
    {
        List<$customTYPE$Model> Execute();
        //List<Customer> Execute();
    }
}
